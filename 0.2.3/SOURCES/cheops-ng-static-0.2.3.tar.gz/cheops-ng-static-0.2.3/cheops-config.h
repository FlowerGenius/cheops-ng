#ifndef CHEOPS_CONFIG_H
#define CHEOPS_CONFIG_H

//#define USING_MONITORING
//#define USING_PLUGINS
//#define USING_SSL
//#define USING_PROBE_PORTS

#endif /* CHEOPS_CONFIG_H */
